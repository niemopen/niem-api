# IEPD Changelog

- 2021-09-17: Version 2.0 [Tom Carlson](mailto:tom@tomcarlsonconsulting.com)
	- Update to NIEM 5.0
	- Removed `PersonFictionalCharacterIndicator`
	- Removed `ItemLengthMeasure`
	- Added GML objects to sample instance
	- Added `PersonDefenestrationIndicator`
	- Added `ContactEmailID`

- 2021-07-12: Version 1.0 [Scott Renner](mailto:sar@mitre.org)

- 2019-11-07: Pre-Release [Scott Renner](mailto:sar@mitre.org)
